Control Scheme for First Playtesting Release

WASD - for player movement (W - up, A - left, S - down, D - right)
Arrow Keys - Slap Attack (directional based on which key pressed, 
i.e. left arrow key slaps to the left)

Cook by standing still in the vicinity of the stove, this increasing temperature
Temperature decreases when not cooking

Reach 30 temperature to win!